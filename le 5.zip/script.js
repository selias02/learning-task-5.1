const catImage = document.getElementById('catImage');
const text = document.getElementById('text');

catImage.addEventListener('click', function() {
  alert('You clicked the cat image!');
});

catImage.addEventListener('mouseover', function() {
  catImage.style.transform = 'scale(1.2)';
  text.innerText = 'You are hovering over the cat image!';
});

catImage.addEventListener('mouseout', function() {
  catImage.style.transform = 'scale(1)';
  text.innerText = 'Click or hover over the cat image!';
});